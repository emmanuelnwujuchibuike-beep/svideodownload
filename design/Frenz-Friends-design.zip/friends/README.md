# Frenz Friends — design handoff

Drop this folder into `design/` as `design/friends/`.

| Screen | Source | Preview |
|---|---|---|
| Friends | Friends.dc.html | previews/01-friends.png |
| Add friends | AddFriends.dc.html | previews/02-add-friends.png |

- Build note: suggestions are TAP ONLY (Skip / Add buttons). Ignore the drag/swipe code, the ADD/SKIP badges and the "Swipe right to add · left to skip" hint in the source files.
- Fonts: Sora (headings), Hanken Grotesk (body). Previews were rendered with Inter as a stand-in.
- People, handles and counts are sample data.
