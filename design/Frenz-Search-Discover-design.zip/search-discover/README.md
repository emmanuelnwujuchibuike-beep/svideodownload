# Frenz Search & Discover — design handoff

Drop this folder into `design/` as `design/search-discover/`.

| Screen | Source | Preview |
|---|---|---|
| Discover | Discover.dc.html | previews/01-discover.png |
| Search, focused (recent + trending) | Search.dc.html | previews/02-search-recent.png |
| Search results (query "fyp") | Search.dc.html with a query typed | previews/03-search-results-fyp.png |

- TAP ONLY. Every Follow button shows an inline spinner on tap, then switches to "Following" (see the pending state in the source).
- Result tabs: Top shows a few of each section with "See all"; Users / Videos / Sounds / Hashtags show only that section.
- Recent searches: tap to search again, × removes one, Clear all, and Turn off / Turn on for search history.
- Fonts: Sora (headings), Hanken Grotesk (body). Previews were rendered with Inter as a stand-in.
- Names, handles, counts and video captions are sample data; video tiles are gradient placeholders for real thumbnails.
