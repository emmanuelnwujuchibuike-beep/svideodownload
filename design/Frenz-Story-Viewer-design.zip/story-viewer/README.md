# Frenz Story Viewer — design handoff

Drop this folder into `design/` as `design/story-viewer/`.

| Screen | Source | Preview |
|---|---|---|
| Your story (owner view) | StoryYours.dc.html | previews/01-your-story.png |
| Watching a story (follower view) | StoryWatching.dc.html | previews/02-watching-a-story.png |
| Story options (⋯ glass sheet) | StoryOptions.dc.html | previews/03-story-options.png |
| Seen by (viewers sheet) | StoryViewers.dc.html | previews/04-seen-by.png |

- `assets/` holds the two story images the screens use (frames from the Frenzsave commercial).
- Screen links point at each other by file name: ⋯ opens Story options, the viewer count opens Seen by.
- Fonts: Sora (headings) and Hanken Grotesk (body). The PNG previews were rendered with Inter as a stand-in, so letter widths differ slightly from the real fonts.
- "Allow resharing" and "Allow replies" are on/off switches; build them as iOS-style toggles.
- Viewer counts, names and reaction numbers are sample data.
